package com.example.attempt2.ui.entry;

import androidx.lifecycle.ViewModel;

public class EntryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}