package com.example.attempt2.ui.home;

import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;



import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;

import com.example.attempt2.R;
import com.example.attempt2.databinding.FragmentHomeBinding;
import com.google.firebase.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class HomeFragment extends Fragment {

    TextView textViewID;
    TextView textViewName;
    EditText editText;
    EditText editTextName;
    DatabaseReference dbRef;

    ImageView ener1;
    ImageView ener2;
    ImageView ener3;

    ImageView tree1;
    ImageView tree2;
    ImageView tree3;

    ImageView cO1;
    ImageView cO2;
    ImageView cO3;

    ImageView cash1;
    ImageView cash2;
    ImageView cash3;


    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        textViewID = root.findViewById(R.id.textView_Title);
        editText = root.findViewById(R.id.editText1);


        dbRef = FirebaseDatabase.getInstance().getReference();

        ener1 = root.findViewById(R.id.ener1);
        ener2 =root.findViewById(R.id.ener2);
        ener3 =root.findViewById(R.id.ener3);
        ener1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadToDB(v);  // Call the upload method when clicked
            }
        });


        SpannableString spannableString = new SpannableString("Greenfluence");
        // Set "Green" to green color
        int greenColor = getResources().getColor(R.color.green);
        spannableString.setSpan(new ForegroundColorSpan(greenColor), 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        // Set "Fluence" to blue color
        int blueColor = getResources().getColor(R.color.blue);
        spannableString.setSpan(new ForegroundColorSpan(blueColor), 5, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        textViewID.setText(spannableString); // Setting text to "GreenFluence"




        View imageView = root.findViewById(R.id.imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadToDB(v);  // Call the upload method when clicked
            }
        });
        return root;
    }

    public void uploadToDB(View view){
        dbRef.child("id").setValue(editText.getText().toString());
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}