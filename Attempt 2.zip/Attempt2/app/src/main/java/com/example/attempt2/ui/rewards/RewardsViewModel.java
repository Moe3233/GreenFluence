package com.example.attempt2.ui.rewards;

import androidx.lifecycle.ViewModel;

public class RewardsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}